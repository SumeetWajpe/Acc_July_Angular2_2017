import {Component,Input} from '@angular/core';

@Component({
    selector:'user',
    template:`<h2> {{userName.login}} </h2>
    
    `
})
export class UserComponent{
  @Input('name')  userName:any="";
}

 