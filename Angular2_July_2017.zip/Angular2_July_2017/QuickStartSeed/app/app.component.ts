// import { Component } from '@angular/core';

// @Component({
//   selector: 'my-app',
// //   template: `<h1>Hello {{name}}</h1>
// //   <course name="ReactJS"></course>
// //   <course name="AngularJS"></course>
// //  <course></course>  
// //   `,

// //template:`<shoppingcart></shoppingcart>`

// // template:`
// //   <h1> List Of Courses </h1>
// //   <ul>
// //     <li *ngFor="let c of courses">
// //       <course [name]="c"></course>
// //     </li>
// //   </ul>
// // `
// })
// export class AppComponent  { 
//   name = 'Angular';
//   courses:string[] = ['React','Node','Angular']

//  }


import { Component } from '@angular/core';
import {UsersService} from './users.service';

@Component({
  selector: 'my-app',
  // template:`<h1>{{name}}</h1>
  //         <img src={{url}} height="100px" width="100px" />
  //         <img [src]="url" height="100px" width="100px" />
          
  //         <br/>

  //         <input type="checkbox"
  //         [(ngModel)]="isSuccess"
  //         />

  //         <input type="button" 
  //         value="Bootstrap !"
  //         class="btn"
  //         [class.btn-success]="isSuccess"
  //         (click)="ClickHandler()" 

  //          />

  //          <br/>

  //          <input type="text"
  //          [(ngModel)]="name" />

  //          <input type="text"
  //          [value]="name"
  //          (input)="ChangeHandler($event)" />  
  // `
  //template:`<shoppingcart></shoppingcart>`

  template:`

        <h1> Routing </h1>
        <a routerLink="/cart" class="btn btn-primary">Shopping Cart </a>
        <a routerLink="/courses" class="btn btn-primary">Courses </a>
  <router-outlet></router-outlet>
  
  `

//  template:`
//            <h1> Users </h1>

//            <ul>
//               <li *ngFor="let user of usersData">
//                 <user [name]="user" ></user>
//               </li>
//            </ul> 
//  `
})
export class AppComponent  { 
  name = 'Angular';
  url:string='https://udemy-images.udemy.com/course/750x422/500628_a962.jpg';
  isSuccess:boolean=true;
  usersData:string[];

  constructor(private userServ:UsersService){

  }

  ngOnInit(){
     let returnedPromise = this.userServ.getUsers();
     returnedPromise.then((resp)=>{
        //console.log(resp.json())
        this.usersData = resp.json();
     },(err)=>{
        console.log(err);
     })

    //this.usersData =  this.userServ.getUsers();
  }


  ChangeHandler(evt:any){
    let theText = evt.target.value;
    this.name = theText;
  }

  ClickHandler(){    
    this.isSuccess = !this.isSuccess;
  }
 }
