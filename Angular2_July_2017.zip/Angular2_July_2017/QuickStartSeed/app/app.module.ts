import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {Routes,RouterModule} from '@angular/router';

import { AppComponent }  from './app.component';
import {CourseComponent} from './course.component';
import {ProductComponent} from './product.component';
import {ShoppingCartComponent} from './shoppingcart.component';
import {UserComponent} from './users.component';

import {UsersService} from './users.service';

import {CutShortPipe} from './cutshort.pipe';

const routes:Routes = [
  {path:'cart',component:ShoppingCartComponent},
  {path:'courses',component:CourseComponent},
  {path:'',redirectTo:'/courses',pathMatch:'full'},
  {path:'**',redirectTo:'/cart',pathMatch:'full'} 
];

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,CourseComponent,ProductComponent,ShoppingCartComponent,CutShortPipe,UserComponent ],
  bootstrap:    [ AppComponent ],
  providers:[UsersService]
})
export class AppModule { }
