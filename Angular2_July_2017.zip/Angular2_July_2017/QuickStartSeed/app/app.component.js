"use strict";
// import { Component } from '@angular/core';
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
// @Component({
//   selector: 'my-app',
// //   template: `<h1>Hello {{name}}</h1>
// //   <course name="ReactJS"></course>
// //   <course name="AngularJS"></course>
// //  <course></course>  
// //   `,
// //template:`<shoppingcart></shoppingcart>`
// // template:`
// //   <h1> List Of Courses </h1>
// //   <ul>
// //     <li *ngFor="let c of courses">
// //       <course [name]="c"></course>
// //     </li>
// //   </ul>
// // `
// })
// export class AppComponent  { 
//   name = 'Angular';
//   courses:string[] = ['React','Node','Angular']
//  }
var core_1 = require("@angular/core");
var users_service_1 = require("./users.service");
var AppComponent = (function () {
    function AppComponent(userServ) {
        this.userServ = userServ;
        this.name = 'Angular';
        this.url = 'https://udemy-images.udemy.com/course/750x422/500628_a962.jpg';
        this.isSuccess = true;
    }
    AppComponent.prototype.ngOnInit = function () {
        var _this = this;
        var returnedPromise = this.userServ.getUsers();
        returnedPromise.then(function (resp) {
            //console.log(resp.json())
            _this.usersData = resp.json();
        }, function (err) {
            console.log(err);
        });
        //this.usersData =  this.userServ.getUsers();
    };
    AppComponent.prototype.ChangeHandler = function (evt) {
        var theText = evt.target.value;
        this.name = theText;
    };
    AppComponent.prototype.ClickHandler = function () {
        this.isSuccess = !this.isSuccess;
    };
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        // template:`<h1>{{name}}</h1>
        //         <img src={{url}} height="100px" width="100px" />
        //         <img [src]="url" height="100px" width="100px" />
        //         <br/>
        //         <input type="checkbox"
        //         [(ngModel)]="isSuccess"
        //         />
        //         <input type="button" 
        //         value="Bootstrap !"
        //         class="btn"
        //         [class.btn-success]="isSuccess"
        //         (click)="ClickHandler()" 
        //          />
        //          <br/>
        //          <input type="text"
        //          [(ngModel)]="name" />
        //          <input type="text"
        //          [value]="name"
        //          (input)="ChangeHandler($event)" />  
        // `
        //template:`<shoppingcart></shoppingcart>`
        template: "\n\n        <h1> Routing </h1>\n        <a routerLink=\"/cart\" class=\"btn btn-primary\">Shopping Cart </a>\n        <a routerLink=\"/courses\" class=\"btn btn-primary\">Courses </a>\n  <router-outlet></router-outlet>\n  \n  "
        //  template:`
        //            <h1> Users </h1>
        //            <ul>
        //               <li *ngFor="let user of usersData">
        //                 <user [name]="user" ></user>
        //               </li>
        //            </ul> 
        //  `
    }),
    __metadata("design:paramtypes", [users_service_1.UsersService])
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map