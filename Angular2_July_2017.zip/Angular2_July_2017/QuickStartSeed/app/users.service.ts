import {Http} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/toPromise';

 @Injectable()
export class UsersService{
    constructor(private http:Http){
    }
    getUsers(){
        //make ajaxified request !
        //return ['Sumeet','Tejas','Vijay'];
        // this.http.get('https://api.github.com/users').subscribe((response)=>console.log(response.json())) // fetches data
         return    this.http.get('https://api.github.com/users').toPromise();
    }
}