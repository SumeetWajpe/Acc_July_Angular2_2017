import {Pipe,PipeTransform} from '@angular/core';

@Pipe({name:'cutshort'})
export class CutShortPipe implements PipeTransform{
        transform(value:string,args:string){

            let maxLimit = (args) ? parseInt(args) : 100;

            if(value){
            return value.substring(0,maxLimit) + '>>>';                
            }
        }
}