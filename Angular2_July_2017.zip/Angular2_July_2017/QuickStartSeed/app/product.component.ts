import {Component,Input} from '@angular/core';

import {Product} from './product';

@Component({
    selector:'product',
    template:`<div class="ProductStyle">
    <h2>{{productDetails.name | uppercase | lowercase }} </h2>
    <img [src]="productDetails.imageUrl" height="100px" width="100px" /> <br/>
    <b>Price : </b> {{productDetails.price | currency:'INR':true }} <br/>
    <b>Quantity : </b> {{productDetails.quantity | number:'2.1-2'}} <br/>
   <!-- <b> Raw Data : </b> {{productDetails }} -->
   <b> Description : </b> {{productDetails.description | cutshort:200}}
        </div>`,
        styles:[`
        .ProductStyle{
    background-color: lightblue;
    border:2px solid black;
    border-radius: 10px;
    margin:10px;
    padding:10px;
}
        `]
})
export class ProductComponent{
 @Input('pdetails')   productDetails:Product;
}