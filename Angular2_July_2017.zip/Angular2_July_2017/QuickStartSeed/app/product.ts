export class Product{    

    constructor();
    constructor( name:string,price:number,quantity:number,imageUrl:string,description:string  );
    constructor(
        public name?:string,
        public price?:number,
        public quantity?:number,
        public imageUrl?:string,
        public description?:string  ){

    }
}