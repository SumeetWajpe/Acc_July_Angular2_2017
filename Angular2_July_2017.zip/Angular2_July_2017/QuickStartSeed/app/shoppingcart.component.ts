import {Component} from '@angular/core';
import {Product} from './product';

@Component({
    selector:'shoppingcart',
    templateUrl:'./app/shoppingcart.html',
    styles:[`
    input.ng-invalid.ng-pristine{
        background-color:yellow;
    }
    input.ng-valid.ng-dirty{
        background-color:lightgreen;
    }
    input.ng-invalid.ng-dirty{
        background-color:red;
    }
    
    `]
    // template:`
    //     <h1> Shopping Cart ! </h1>

    //     <h2> Launch Date : {{launchDate | date:'short'}} </h2> 
    //     <ul> 
    //         <li *ngFor="let everyproduct of listOfProducts" >
    //             <product [pdetails]="everyproduct" ></product>
    //         </li>   
    //     </ul>
    // `
})
export class ShoppingCartComponent{
  // product1:any={name:'Mobile',price:20000,quantity:10}

//product1:Product;
listOfProducts:Product[];
launchDate:Date = new Date();
newProduct:Product ;

constructor(){
    // this.product1 = new Product(
    //     "Mobile",
    //     40000,
    //     10,
    //     'http://neowebsolution.com/rupak/nancy_mobile/wp-content/uploads/2016/09/Mobile-Phones.jpg'
    // );
    this.newProduct = new Product();
    
    this.listOfProducts = [

        new Product(
        "Mobile",
        40000,
        10,
        'http://neowebsolution.com/rupak/nancy_mobile/wp-content/uploads/2016/09/Mobile-Phones.jpg',
        `Achieve the maximum speed possible on the Web Platform today, and take it further, via Web Workers and server-side rendering.

Angular puts you in control over scalability. Meet huge data requirements by building data models on RxJS, Immutable.js or another push-model.`
        ),
         new Product(
        "Laptop",
        60000,
        70.7848,
        'http://ssl-product-images.www8-hp.com/digmedialib/prodimg/lowres/c05059975.png',
        `Achieve the maximum speed possible on the Web Platform today, and take it further, via Web Workers and server-side rendering.

Angular puts you in control over scalability. Meet huge data requirements by building data models on RxJS, Immutable.js or another push-model.`
        ),
         new Product(
        "Earphones",
        1000,
        180,
        'https://s3-ap-southeast-2.amazonaws.com/wc-prod-pim/Category_400x400/noise-cancel.jpg',
        `Achieve the maximum speed possible on the Web Platform today, and take it further, via Web Workers and server-side rendering.

Angular puts you in control over scalability. Meet huge data requirements by building data models on RxJS, Immutable.js or another push-model.`
        ),
         new Product(
        "Sofa",
        90000,
        10,
        'https://images2.roomstogo.com/is/image/roomstogo/lr_sof_8503378p_newportcove_cardinal~Cindy-Crawford-Home-Newport-Cove-Cardinal-Sofa.jpeg?$PDP_Primary_936x650$',
        `Achieve the maximum speed possible on the Web Platform today, and take it further, via Web Workers and server-side rendering.

Angular puts you in control over scalability. Meet huge data requirements by building data models on RxJS, Immutable.js or another push-model.`
        ),
         new Product(
        "Camera",
        90000,
        90,
        'https://pisces.bbystatic.com/BestBuy_US/images/products/2805/2805027_sd.jpg;maxHeight=460;maxWidth=460',
        `Achieve the maximum speed possible on the Web Platform today, and take it further, via Web Workers and server-side rendering.

Angular puts you in control over scalability. Meet huge data requirements by building data models on RxJS, Immutable.js or another push-model.`
        )

    ];


}

CalledOnSubmit(){
    // ??

    let newProductToBeAdded:Product = new Product();
    newProductToBeAdded.name = this.newProduct.name;
    newProductToBeAdded.price = this.newProduct.price;
    newProductToBeAdded.quantity = this.newProduct.quantity;
    

    this.listOfProducts.push(newProductToBeAdded);
}


}